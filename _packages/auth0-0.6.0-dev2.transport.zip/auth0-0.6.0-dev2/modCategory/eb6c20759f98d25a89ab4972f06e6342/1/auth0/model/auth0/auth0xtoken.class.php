<?php
/**
 * @package auth0
 */
class Auth0XToken extends xPDOSimpleObject {}
?>